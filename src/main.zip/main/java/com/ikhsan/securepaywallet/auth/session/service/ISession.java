package com.ikhsan.securepaywallet.auth.session.service;

import com.ikhsan.securepaywallet.auth.session.entity.SessionEntity;
import com.ikhsan.securepaywallet.user.entity.UserEntity;

public interface ISession {

    public SessionEntity createSession(UserEntity user);

}
