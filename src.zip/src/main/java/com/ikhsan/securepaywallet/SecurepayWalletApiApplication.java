package com.ikhsan.securepaywallet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
public class SecurepayWalletApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurepayWalletApiApplication.class, args);
	}

}
